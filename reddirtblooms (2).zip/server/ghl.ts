/**
 * GoHighLevel CRM sync helper (v2 API)
 * Pushes contacts to GHL and keeps tags in sync.
 */

const GHL_BASE = "https://services.leadconnectorhq.com";
const GHL_VERSION = "2021-07-28";

function ghlHeaders() {
  return {
    Authorization: `Bearer ${process.env.GHL_API_KEY}`,
    Version: GHL_VERSION,
    "Content-Type": "application/json",
  };
}

/** Look up a contact by email in GHL v2. Returns the contact id or null. */
async function findContactByEmail(email: string): Promise<string | null> {
  const locationId = process.env.GHL_LOCATION_ID;
  if (!locationId) return null;

  try {
    const url = `${GHL_BASE}/contacts/search`;
    const res = await fetch(url, {
      method: "POST",
      headers: ghlHeaders(),
      body: JSON.stringify({
        locationId,
        pageLimit: 1,
        filters: [{ field: "email", operator: "eq", value: email }],
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.warn("[GHL] Contact search failed:", res.status, res.statusText, errText);
      return null;
    }

    const data = (await res.json()) as { contacts?: { id: string }[] };
    return data.contacts?.[0]?.id ?? null;
  } catch (err) {
    console.error("[GHL] Contact search error:", err);
    return null;
  }
}

/**
 * Create or update a florist contact in GHL.
 * Called on registration — creates the contact with the florist-applicant tag.
 */
export async function syncFloristToGHL(florist: {
  email: string;
  contactName: string;
  businessName: string;
  phone?: string | null;
  city?: string | null;
  website?: string | null;
  status: "pending" | "approved" | "declined";
}): Promise<string | null> {
  const locationId = process.env.GHL_LOCATION_ID?.trim();
  const apiKey = process.env.GHL_API_KEY?.trim();

  if (!locationId || !apiKey) {
    console.error("[GHL] CRITICAL: Missing credentials. GHL_API_KEY or GHL_LOCATION_ID not configured.");
    console.error("[GHL] locationId:", locationId ? "set" : "MISSING");
    console.error("[GHL] apiKey:", apiKey ? "set" : "MISSING");
    return null;
  }

  const nameParts = florist.contactName.trim().split(/\s+/);
  const firstName = nameParts[0] ?? "";
  const lastName = nameParts.slice(1).join(" ") || "";

  const tag = statusToTag(florist.status);

  const payload: Record<string, unknown> = {
    locationId,
    firstName,
    lastName,
    email: florist.email,
    companyName: florist.businessName,
    tags: [tag, "florist-portal"],
    source: "Red Dirt Blooms Website",
  };

  if (florist.phone) payload.phone = florist.phone;
  if (florist.city) payload.city = florist.city;
  if (florist.website) payload.website = florist.website;

  try {
    console.log("[GHL] Starting sync for:", florist.email);

    const existingId = await findContactByEmail(florist.email);
    console.log("[GHL] Existing contact check:", existingId ? "found" : "not found");

    if (existingId) {
      // GHL v2 PUT does NOT accept locationId in the body — strip it
      const { locationId: _loc, ...updatePayload } = payload as Record<string, unknown>;
      void _loc;
      const res = await fetch(`${GHL_BASE}/contacts/${existingId}`, {
        method: "PUT",
        headers: ghlHeaders(),
        body: JSON.stringify(updatePayload),
      });
      if (!res.ok) {
        const err = await res.text();
        console.error("[GHL] Update contact failed:", res.status, err);
        return null;
      }
      console.log("[GHL] Updated contact:", existingId);
      return existingId;
    } else {
      const res = await fetch(`${GHL_BASE}/contacts/`, {
        method: "POST",
        headers: ghlHeaders(),
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const errBody = await res.json() as { message?: string; meta?: { contactId?: string } };
        // GHL returns the existing contact ID in meta.contactId when blocking a duplicate.
        // Use it to update the existing contact instead of failing.
        const duplicateId = errBody?.meta?.contactId;
        if (duplicateId) {
          console.log("[GHL] Duplicate detected — updating existing contact:", duplicateId);
          const { locationId: _loc, ...updatePayload } = payload as Record<string, unknown>;
          void _loc;
          const upRes = await fetch(`${GHL_BASE}/contacts/${duplicateId}`, {
            method: "PUT",
            headers: ghlHeaders(),
            body: JSON.stringify(updatePayload),
          });
          if (!upRes.ok) {
            const upErr = await upRes.text();
            console.error("[GHL] Duplicate update failed:", upRes.status, upErr);
            return null;
          }
          console.log("[GHL] Updated duplicate contact:", duplicateId);
          return duplicateId;
        }
        console.error("[GHL] Create contact failed:", res.status, JSON.stringify(errBody));
        return null;
      }
      const data = (await res.json()) as { contact?: { id: string } };
      const newId = data.contact?.id ?? null;
      console.log("[GHL] Created contact:", newId);
      return newId;
    }
  } catch (err) {
    console.error("[GHL] Sync error:", err);
    return null;
  }
}

/**
 * Update the status tag on an existing GHL contact.
 * Called when admin approves or declines a florist application.
 */
export async function updateFloristStatusInGHL(
  email: string,
  status: "pending" | "approved" | "declined"
): Promise<void> {
  if (!process.env.GHL_API_KEY || !process.env.GHL_LOCATION_ID) return;

  try {
    const contactId = await findContactByEmail(email);
    if (!contactId) {
      console.warn("[GHL] Contact not found for status update:", email);
      return;
    }

    const tag = statusToTag(status);

    const tagsToRemove = ["florist-applicant", "florist-approved", "florist-declined"].filter(
      (t) => t !== tag
    );

    await fetch(`${GHL_BASE}/contacts/${contactId}/tags`, {
      method: "POST",
      headers: ghlHeaders(),
      body: JSON.stringify({ tags: [tag] }),
    });

    for (const oldTag of tagsToRemove) {
      await fetch(`${GHL_BASE}/contacts/${contactId}/tags`, {
        method: "DELETE",
        headers: ghlHeaders(),
        body: JSON.stringify({ tags: [oldTag] }),
      });
    }

    console.log(`[GHL] Updated status tag to ${tag} for contact:`, contactId);
  } catch (err) {
    console.error("[GHL] Status update error:", err);
  }
}

/**
 * Create or update a generic contact in GHL with specified tags.
 * Used for Bloom Watch signups, Bouquet Bar inquiries, and Stripe order customers.
 */
export async function syncContactToGHL(contact: {
  email: string;
  name?: string | null;
  phone?: string | null;
  tags: string[];
  source?: string;
  customFields?: Array<{ key: string; field_value: string }>;
}): Promise<string | null> {
  const locationId = process.env.GHL_LOCATION_ID?.trim();
  const apiKey = process.env.GHL_API_KEY?.trim();
  if (!locationId || !apiKey) {
    console.warn("[GHL] Missing credentials — skipping contact sync for:", contact.email);
    return null;
  }
  const nameParts = (contact.name ?? "").trim().split(/\s+/);
  const firstName = nameParts[0] ?? "";
  const lastName = nameParts.slice(1).join(" ") || "";
  const payload: Record<string, unknown> = {
    locationId,
    firstName,
    lastName,
    email: contact.email,
    tags: contact.tags,
    source: contact.source ?? "Red Dirt Blooms Website",
    ...(contact.customFields?.length ? { customFields: contact.customFields } : {}),
  };
  if (contact.phone) payload.phone = contact.phone;
  try {
    const existingId = await findContactByEmail(contact.email);
    if (existingId) {
      // GHL v2 PUT does NOT accept locationId in the body — strip it
      const { locationId: _loc, ...updatePayload } = payload as Record<string, unknown>;
      void _loc;
      const res = await fetch(`${GHL_BASE}/contacts/${existingId}`, {
        method: "PUT",
        headers: ghlHeaders(),
        body: JSON.stringify(updatePayload),
      });
      if (!res.ok) {
        const err = await res.text();
        console.error("[GHL] Update contact failed:", res.status, err);
        return null;
      }
      console.log(`[GHL] Updated contact ${existingId} with tags:`, contact.tags);
      return existingId;
    } else {
      const res = await fetch(`${GHL_BASE}/contacts/`, {
        method: "POST",
        headers: ghlHeaders(),
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const err = await res.text();
        console.error("[GHL] Create contact failed:", res.status, err);
        return null;
      }
      const data = (await res.json()) as { contact?: { id: string } };
      const newId = data.contact?.id ?? null;
      console.log(`[GHL] Created contact ${newId} with tags:`, contact.tags);
      return newId;
    }
  } catch (err) {
    console.error("[GHL] syncContactToGHL error:", err);
    return null;
  }
}

function statusToTag(status: "pending" | "approved" | "declined"): string {
  switch (status) {
    case "pending":
      return "florist-applicant";
    case "approved":
      return "florist-approved";
    case "declined":
      return "florist-declined";
  }
}
